fail2ban.server.jails module
============================

.. automodule:: fail2ban.server.jails
    :members:
    :undoc-members:
    :show-inheritance:
